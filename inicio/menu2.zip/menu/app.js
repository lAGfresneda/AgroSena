const readline = require('readline');
const colors = require('colors');
const ProductosVenta = require('./proy_modules/clase');

const productosventa = new ProductosVenta();
const archivoJson = './proy_modules/productos.json';

const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout
});

const mostrarMenu = () => {
    return new Promise((resolve) => {
        console.clear();
        console.log('**************************'.green);
        console.log('       MENÚ PRINCIPAL     '.green);
        console.log('**************************'.green);
        console.log(`${'1.'.cyan} Cargar Datos`);
        console.log(`${'2.'.cyan} Grabar nuevos datos`);
        console.log(`${'3.'.cyan} Borrar productos`);
        console.log(`${'4.'.cyan} Opción 4`);
        console.log(`${'5.'.cyan} Opción 5`);
        console.log(`${'6.'.cyan} Opción 6`);
        console.log(`${'0.'.cyan} Cerrar App`);

        rl.question('Ingrese el número de la opción deseada: '.yellow, (respuesta) => {
            resolve(respuesta);
        });
    });
};
const manejarOpcion = (opcion) => {
    return new Promise(async (resolve, reject) => {
        try {
            switch (opcion) {
                case '0':
                    resolve('Saliendo del menú...'.grey);
                    break;
                case '1':
                    console.clear();
                    console.log('**************************'.green);
                    console.log('       MENÚ PRINCIPAL     '.green);
                    console.log('**************************'.green);
                    console.log(`seleccionaste la opcion : ${opcion}. Cargar datos`)
                    await productosventa.leerProductos(archivoJson);
                    productosventa.mostrarProductosEnTabla();
                    await esperarEnter(); // Esperar a que el usuario presione Enter
                    resolve('Datos cargados exitosamente'.green);
                    break;
                case '2':
                    // Lógica para grabar nuevos datos
                    resolve('Nuevo producto grabado'.green);
                    break;
                case '3':
                    // Lógica para borrar productos
                    resolve('Productos borrados exitosamente'.green);
                    break;
                case '4':
                case '5':
                case '6':
                    resolve(`Seleccionaste la opción ${opcion}`.magenta);
                    break;
                default:
                    reject(new Error('Opción no válida, por favor elige un número del 0 al 6.'.red));
            }
        } catch (error) {
            reject(new Error(`Error al manejar la opción: ${error.message}`));
        }
    });
};



const esperarEnter = () => {
    return new Promise((resolve) => {
        rl.question(`\nPresiona ${'Enter'.yellow} para volver al menú...`, () => {
            resolve();
        });
    });
};

const mostrarCargando = async () => {
    const puntos = ['.', '..', '...'];
    let index = 0;

    return new Promise((resolve) => {
        const intervalo = setInterval(() => {
            process.stdout.write(`\rCargando ${puntos[index]}`);
            index = (index + 1) % puntos.length;
        }, 800);

        setTimeout(() => {
            clearInterval(intervalo);
            console.log(' ¡Listo!');
            resolve();
        }, 3000);
    });
};

const ejecutarMenu = async () => {
    let continuar = true;

    do {
        try {
            const opcion = await mostrarMenu();
            const mensaje = await manejarOpcion(opcion);
            console.clear();
            console.log('**************************'.green);
            console.log('       MENÚ PRINCIPAL     '.green);
            console.log('**************************'.green);
            console.log(mensaje);

            if (mensaje.includes('Saliendo')) {
                continuar = false;
                rl.close();
                await mostrarCargando();
                console.log('Saliste del menú'.red);
            } else {
                await esperarEnter();
            }
        } catch (error) {
            console.clear();
            console.log('**************************'.green);
            console.log('       MENÚ PRINCIPAL     '.green);
            console.log('**************************'.green);
            console.error(error);
            await esperarEnter();
        }
    } while (continuar);
};

ejecutarMenu();
