// En tu archivo proy_modules/producto.js

class Producto {
    #codigoProducto;
    #nombreProducto;
    #inventarioProducto;
    #precioProducto;

    constructor(codigoProducto, nombreProducto, inventarioProducto, precioProducto) {
        this.#codigoProducto = codigoProducto;
        this.#nombreProducto = nombreProducto;
        this.#inventarioProducto = inventarioProducto;
        this.#precioProducto = precioProducto;
    }

    get getCodigoProducto() {
        return this.#codigoProducto;
    }

    set setCodigoProducto(value) {
        this.#codigoProducto = value;
    }

    get getNombreProducto() {
        return this.#nombreProducto;
    }

    set setNombreProducto(value) {
        this.#nombreProducto = value;
    }

    get getInventarioProducto() {
        return this.#inventarioProducto;
    }

    set setInventarioProducto(value) {
        this.#inventarioProducto = value;
    }

    get getPrecioProducto() {
        return this.#precioProducto;
    }

    set setPrecioProducto(value) {
        this.#precioProducto = value;
    }
    }

module.exports = Producto;
