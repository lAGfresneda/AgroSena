const fs = require('fs'); // Importa el módulo 'fs' para trabajar con archivos del sistema.


const rutaArchivo = './proy_modules/productos.json';

class ProductosVenta {
    #listaProductos = [];

    constructor() {
        // Inicializar con una lista vacía de productos
        this.#listaProductos = [];
    }

    async cargarProductos() {
        // Cargar productos desde el archivo JSON
        try {
            const data = fs.readFileSync(rutaArchivo, 'utf8');
            const productos = JSON.parse(data);

            // this.#listaProductos = productos;
            // this.mostrarProductosEnTabla();
            console.table(productos);


        } catch (error) {
            console.error('Error al cargar productos:', error);
        }
    }

    mostrarProductosEnTabla() {
        // Preparar datos para la tabla
        const data = this.#listaProductos.map(p => ({
            Código: p.codigoProducto,
            Nombre: p.nombreProducto,
            Inventario: p.inventarioProducto,
            Precio: p.precioProducto.toFixed(2) // Ajusta el formato de precio si es necesario
        }));

        // Mostrar la tabla en consola
        console.table(data);

        console.log(`Total de productos: ${this.#listaProductos.length}`.green);
    }
}

module.exports = ProductosVenta;
