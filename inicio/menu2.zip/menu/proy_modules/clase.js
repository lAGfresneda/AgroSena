const fs = require('fs');

class Productos {
    #codigoProducto;
    #nombreProducto;
    #inventarioProducto;
    #precioProducto;

    constructor(codigoProducto, nombreProducto, inventarioProducto, precioProducto) {
        this.#codigoProducto = codigoProducto;
        this.#nombreProducto = nombreProducto;
        this.#inventarioProducto = inventarioProducto;
        this.#precioProducto = precioProducto;
    }

    get getCodigoProducto() {
        return this.#codigoProducto;
    }

    set setCodigoProducto(value) {
        this.#codigoProducto = value;
    }

    get getNombreProducto() {
        return this.#nombreProducto;
    }

    set setNombreProducto(value) {
        this.#nombreProducto = value;
    }

    get getInventarioProducto() {
        return this.#inventarioProducto;
    }

    set setInventarioProducto(value) {
        this.#inventarioProducto = value;
    }

    get getPrecioProducto() {
        return this.#precioProducto;
    }

    set setPrecioProducto(value) {
        this.#precioProducto = value;
    }
}

class ProductosVenta {
    #listaProductos = [];

    constructor() {
        this.#listaProductos = [];
    }

    leerProductos(archivoJson) {
        return new Promise((resolve, reject) => {
            fs.readFile(archivoJson, 'utf-8', (err, data) => {
                if (err) {
                    reject(err);
                    return;
                }
                const productos = JSON.parse(data);
                const productosClase = [];

                productos.forEach((productoJSON) => {
                    const producto = new Productos(
                        productoJSON.codigoProducto,
                        productoJSON.nombreProducto,
                        productoJSON.inventarioProducto,
                        productoJSON.precioProducto
                    );
                    productosClase.push(producto);
                });
                this.#listaProductos = productosClase;
                resolve(productosClase);
            });
        });
    }

    mostrarProductosEnTabla() {
        console.table(this.#listaProductos.map(producto => ({
            'Código': producto.getCodigoProducto,
            'Nombre': producto.getNombreProducto,
            'Inventario': producto.getInventarioProducto,
            'Precio': producto.getPrecioProducto
        })));
    }
}

module.exports = ProductosVenta;
